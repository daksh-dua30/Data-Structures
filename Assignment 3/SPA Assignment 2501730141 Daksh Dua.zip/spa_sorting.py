import random
import time

# Sorting Algorithms


def insertion_sort(arr):
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = key
    return arr


def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result


def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)


def partition(arr, low, high):
    # using random pivot to avoid worst-case recursion
    pivot_index = random.randint(low, high)
    arr[pivot_index], arr[high] = arr[high], arr[pivot_index]
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


def quick_sort(arr, low, high):
    if low < high:
        pi = partition(arr, low, high)
        quick_sort(arr, low, pi - 1)
        quick_sort(arr, pi + 1, high)
    return arr

# Timing


def measure_time(func, arr):
    temp = arr.copy()
    start = time.time()

    if func == quick_sort:
        func(temp, 0, len(temp) - 1)
    else:
        func(temp)

    end = time.time()
    return (end - start) * 1000  # ms

# Dataset


def generate_datasets(size):
    random.seed(42)
    rand = [random.randint(1, 100000) for _ in range(size)]
    sorted_arr = list(range(size))
    reverse_arr = list(range(size, 0, -1))
    return rand, sorted_arr, reverse_arr

# Main


if __name__ == "__main__":
    print("--- Correctness Check ---")
    test = [5, 2, 9, 1, 5, 6]
    print("Original:", test)
    print("Insertion:", insertion_sort(test.copy()))
    print("Merge:", merge_sort(test.copy()))
    temp = test.copy()
    quick_sort(temp, 0, len(temp)-1)
    print("Quick:", temp)

    sizes = [1000, 5000, 10000]

    print("\n--- Performance Table (ms) ---")
    print(f"{'Size':<8}{'Type':<12}{'Insertion':<12}{'Merge':<12}{'Quick':<12}")

    for size in sizes:
        rand, sorted_arr, reverse_arr = generate_datasets(size)

        for name, data in [("Random", rand), ("Sorted", sorted_arr), ("Reverse", reverse_arr)]:
            t1 = measure_time(insertion_sort, data)
            t2 = measure_time(merge_sort, data)
            t3 = measure_time(quick_sort, data)

            print(
                f"{size:<8}{name:<12}{round(t1, 2):<12}{round(t2, 2):<12}{round(t3, 2):<12}")
