# ----------- BST -----------

class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, key):
        def _insert(node, key):
            if not node:
                return BSTNode(key)
            if key < node.key:
                node.left = _insert(node.left, key)
            else:
                node.right = _insert(node.right, key)
            return node
        self.root = _insert(self.root, key)

    def search(self, key):
        cur = self.root
        while cur:
            if key == cur.key:
                return True
            elif key < cur.key:
                cur = cur.left
            else:
                cur = cur.right
        return False

    def _min_value_node(self, node):
        cur = node
        while cur and cur.left:
            cur = cur.left
        return cur

    def delete(self, key):
        def _delete(node, key):
            if not node:
                return None

            if key < node.key:
                node.left = _delete(node.left, key)
            elif key > node.key:
                node.right = _delete(node.right, key)
            else:
                # case 1: no child
                if not node.left and not node.right:
                    return None
                # case 2: one child
                if not node.left:
                    return node.right
                if not node.right:
                    return node.left
                # case 3: two children
                temp = self._min_value_node(node.right)
                node.key = temp.key
                node.right = _delete(node.right, temp.key)
            return node
        self.root = _delete(self.root, key)

    def inorder(self):
        res = []

        def _in(node):
            if node:
                _in(node.left)
                res.append(node.key)
                _in(node.right)
        _in(self.root)
        print(res)


# ----------- GRAPH -----------

class Graph:
    def __init__(self):
        self.adj = {}

    def add_edge(self, u, v, w):
        if u not in self.adj:
            self.adj[u] = []
        self.adj[u].append((v, w))

    def print_graph(self):
        for k in self.adj:
            print(k, "->", self.adj[k])

    def bfs(self, start):
        visited = set()
        queue = [start]
        order = []

        while queue:
            node = queue.pop(0)
            if node not in visited:
                visited.add(node)
                order.append(node)
                for nei, _ in self.adj.get(node, []):
                    if nei not in visited:
                        queue.append(nei)
        print("BFS:", order)

    def dfs(self, start):
        visited = set()
        order = []

        def _dfs(node):
            if node in visited:
                return
            visited.add(node)
            order.append(node)
            for nei, _ in self.adj.get(node, []):
                _dfs(nei)

        _dfs(start)
        print("DFS:", order)


# ----------- HASH TABLE -----------

class HashTable:
    def __init__(self, size=5):
        self.size = size
        self.table = [[] for _ in range(size)]

    def _hash(self, key):
        return key % self.size

    def insert(self, key, value):
        idx = self._hash(key)
        for i, (k, v) in enumerate(self.table[idx]):
            if k == key:
                self.table[idx][i] = (key, value)
                return
        self.table[idx].append((key, value))

    def get(self, key):
        idx = self._hash(key)
        for k, v in self.table[idx]:
            if k == key:
                return v
        return None

    def delete(self, key):
        idx = self._hash(key)
        for i, (k, v) in enumerate(self.table[idx]):
            if k == key:
                self.table[idx].pop(i)
                return

    def print_table(self):
        for i, bucket in enumerate(self.table):
            print(i, "->", bucket)


# ----------- MAIN -----------

if __name__ == "__main__":
    print("--- BST ---")
    bst = BST()
    vals = [50, 30, 70, 20, 40, 60, 80]
    for v in vals:
        bst.insert(v)
    bst.inorder()

    print("Search 20:", bst.search(20))
    print("Search 90:", bst.search(90))

    print("Delete leaf (20)")
    bst.delete(20)
    bst.inorder()

    print("Insert 65, then delete 60 (one child case)")
    bst.insert(65)
    bst.delete(60)
    bst.inorder()

    print("Delete node with 2 children (30)")
    bst.delete(30)
    bst.inorder()

    print("\n--- GRAPH ---")
    g = Graph()
    edges = [
        ('A', 'B', 2), ('A', 'C', 4), ('B', 'D', 7), ('B', 'E', 3),
        ('C', 'E', 1), ('D', 'F', 5), ('E', 'D', 2), ('E', 'F', 6), ('C', 'F', 8)
    ]
    for u, v, w in edges:
        g.add_edge(u, v, w)

    g.print_graph()
    g.bfs('A')
    g.dfs('A')

    print("\n--- HASH TABLE ---")
    ht = HashTable(5)
    keys = [10, 15, 20, 7, 12]
    for k in keys:
        ht.insert(k, k*10)

    ht.print_table()

    print("Get 10:", ht.get(10))
    print("Get 7:", ht.get(7))
    print("Get 20:", ht.get(20))

    print("Delete 15")
    ht.delete(15)
    ht.print_table()
